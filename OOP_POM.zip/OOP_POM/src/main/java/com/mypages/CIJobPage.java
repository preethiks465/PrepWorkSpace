package com.mypages;

import org.openqa.selenium.WebDriver;

public class CIJobPage extends BasePage {

	public CIJobPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

}
