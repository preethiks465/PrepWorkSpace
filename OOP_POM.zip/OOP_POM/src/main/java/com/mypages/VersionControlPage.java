package com.mypages;

import org.openqa.selenium.WebDriver;

public class VersionControlPage extends BasePage {

	public VersionControlPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

}
